import { homeOfferings } from "@/data/site";
import { Container } from "@/components/ui/Container";

export function TrustedBy() {
  const items = [...homeOfferings, ...homeOfferings];

  return (
    <section className="overflow-hidden border-b border-border bg-white py-6">
      <Container>
        <p className="text-eyebrow mb-4 text-center text-grey-olive">
          One team for merch, print, and outreach
        </p>

        {/* Static wrap on mobile — avoids marquee overflow */}
        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 md:hidden">
          {homeOfferings.map((offering) => (
            <span
              key={offering}
              className="text-xs font-medium text-silver sm:text-sm"
            >
              {offering}
            </span>
          ))}
        </div>

        <div className="relative hidden overflow-hidden md:block">
          <div className="animate-marquee flex w-max gap-12 lg:gap-16">
            {items.map((offering, i) => (
              <span
                key={`${offering}-${i}`}
                className="whitespace-nowrap text-sm font-medium text-silver lg:text-base"
              >
                {offering}
              </span>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
